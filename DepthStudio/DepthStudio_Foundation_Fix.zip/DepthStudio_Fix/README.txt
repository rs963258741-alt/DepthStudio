Depth Studio 編譯修正檔

這是「單檔替換包」，不是完整專案 ZIP。
將 DepthStudio/AtmosUDDFParser.swift 覆蓋 GitHub 專案內同路徑的檔案即可。
本次修正：移除 import FoundationXML，保留 import Foundation。
其他原始碼沒有更動。完成替換後，回到 Codemagic 再執行一次 Build。
