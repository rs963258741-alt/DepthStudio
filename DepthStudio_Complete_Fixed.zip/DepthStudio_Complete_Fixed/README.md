# Depth Studio

Native iOS SwiftUI project for synchronizing freediving UDDF telemetry with action-camera video.

## Included functionality

- ATMOS Mission2 UDDF XML import and parsing
- Dive summary: maximum / average depth, duration, sample count and device metadata
- Video import (MP4 / MOV) and AVPlayer preview
- Fixed-offset timeline synchronization
- Linear depth / temperature interpolation and vertical speed
- Adjustable telemetry HUD preview
- AVFoundation / Core Animation MP4-export implementation (export UI integration and device-level validation remain separate work)

## Build with Codemagic

The repository root must contain `codemagic.yaml` and `project.yml`.

1. Codemagic installs XcodeGen when it is not already available.
2. XcodeGen generates `DepthStudio.xcodeproj` from `project.yml`.
3. Xcode builds the unsigned iOS app for the generic iOS device destination.

The workflow is configured for an unsigned build. An unsigned `.app` cannot be installed directly on a physical iPhone; installation and TestFlight distribution require Apple code signing.

## Local build on macOS

Requires Xcode and XcodeGen:

```sh
xcodegen generate --spec project.yml
xcodebuild \
  -project DepthStudio.xcodeproj \
  -scheme DepthStudio \
  -configuration Debug \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  clean build
```

## Compatibility notes

- Minimum deployment target: iOS 17.0.
- The video importer uses `UTType.mpeg4Movie` for MPEG-4 files and `UTType.quickTimeMovie` for QuickTime files.
- `FoundationXML` is imported conditionally for cross-platform core testing; Apple platforms that expose `XMLParser` through Foundation do not require that module.
- The exporter currently uses the iOS 17-compatible `AVAssetExportSession` callback API. Depending on the Xcode concurrency diagnostics, it may emit a non-blocking Sendable warning.

## Scope / validation

This package preserves the project structure and core feature set in the source archive and incorporates the later exporter and core-source revisions. The current preview screen imports a UDDF file and a video, then displays the synchronized HUD. The exporter implementation is included in the target but an export button / export workflow is not yet wired into the visible screen.
